# Calcolatore Volume & Costo 3D

Tool web per calcolare il costo di stampa 3D a partire dalle dimensioni di un oggetto inscritto in un parallelepipedo.

## Funzionalità

- Inserimento dimensioni parallelepipedo (mm)
- Fattore di riempimento % con slider
- Selezione materiale con costo preimpostato: PLA, PETG, ABS, ASA, TPU, Resina
- Costo per cm³ modificabile manualmente
- Calcolo automatico volume e costo totale

## Deploy su Vercel (gratuito)

### Metodo 1 — tramite GitHub (consigliato)

1. Crea un account su [github.com](https://github.com) se non ce l'hai
2. Crea un nuovo repository (es. `calcolatore-volume`)
3. Carica tutti i file di questa cartella nel repository
4. Vai su [vercel.com](https://vercel.com) e accedi con GitHub
5. Clicca **"Add New Project"** → seleziona il repository
6. Vercel rileva automaticamente React → clicca **"Deploy"**
7. In 1-2 minuti hai il tuo link pubblico (es. `calcolatore-volume.vercel.app`)

### Metodo 2 — tramite Vercel CLI

```bash
npm install -g vercel
cd calcolatore-volume
vercel
```

Segui le istruzioni a schermo. Al termine ricevi il link pubblico.

## Modifica i costi dei materiali

I costi preimpostati si trovano in `src/App.jsx` nelle prime righe:

```js
const MATERIALS = [
  { id: "pla",    name: "PLA",    costo: 0.04,  ... },
  { id: "petg",   name: "PETG",   costo: 0.06,  ... },
  ...
];
```

Modifica il valore `costo` (in €/cm³) per aggiornare i prezzi.
Dopo la modifica, fai un nuovo deploy su Vercel (si aggiorna automaticamente se usi GitHub).

## Struttura file

```
calcolatore-volume/
├── public/
│   └── index.html
├── src/
│   ├── App.jsx       ← componente principale
│   └── index.js      ← entry point
├── package.json
└── README.md
```
